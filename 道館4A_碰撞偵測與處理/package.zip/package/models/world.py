from typing import List, Optional
from pydantic import BaseModel, PrivateAttr
from .sprite import Sprite

class World(BaseModel):
    _length_obj: int = PrivateAttr(30)
    _sprites_obj: List[Sprite] = PrivateAttr(default_factory=list)

    def __init__(self, length: int = 30, **data):
        super().__init__(**data)
        object.__setattr__(self, "_length_obj", int(length))
        object.__setattr__(self, "_sprites_obj", [])

    @property
    def _length(self) -> int:
        return self._length_obj

    @_length.setter
    def _length(self, value: int) -> None:
        v = int(value)
        if v <= 0:
            raise ValueError("Length must be a positive integer")
        object.__setattr__(self, "_length_obj", v)

    @property
    def _sprites(self) -> List[Sprite]:
        return self._sprites_obj

    @_sprites.setter
    def _sprites(self, value: List[Sprite]) -> None:
        object.__setattr__(self, "_sprites_obj", list(value))

    def _create(self, sprites: List[Sprite]) -> None:
        if len(sprites) < 10:
            raise ValueError("There must be at least 10 sprites to create the world")
        self._sprites = sprites

    def _find_sprite_at(self, pos: int, exclude: Optional[Sprite] = None):
        """Return a sprite at position `pos`, or None. If `exclude` is provided,
        that sprite will be ignored (useful to avoid detecting the mover itself).
        """
        for s in self._sprites:
            if exclude is not None and s is exclude:
                continue
            if s._position() == pos:
                return s
        return None

    def _start_loop(self) -> None:
        """
        1. 先抓出所有可選的sprite位置
        2. 讓使用者選擇要移動的sprite以及移動目的 0 <= 要移動的位置 <= 30, 如果不符合約束的話要回傳invalid move 請使用者重新選
        3. 移動sprite 並且判斷是否有碰撞 (要判斷前感覺要抓出所有sprite位置 要從sprite裡面抓 而不是直接從coord抓)
        4. 如果有碰撞的話就執行碰撞處理 4.1 如果沒有碰撞就直接移動該sprite過去並且更新coord 4.2如果有碰撞就依序執行圖中的兩物件碰撞邏輯
        5. 重複以上步驟
        """
        print("Starting interactive loop. Enter 'q' to quit.")
        while True:
            # 1. 列出所有可選的 sprite 與位置
            for idx, s in enumerate(self._sprites):
                print(f"{idx}: {s.__class__.__name__} at {s._position()}")

            # 2. 讓使用者選擇要移動的 sprite
            sel = input("Select sprite index to move (or 'q' to quit): ")
            if sel.strip().lower() == "q":
                print("Exiting loop")
                break
            try:
                sel_idx = int(sel)
                if not (0 <= sel_idx < len(self._sprites)):
                    print("invalid move: index out of range")
                    continue
            except ValueError:
                print("invalid move: not an integer")
                continue

            dest = input(f"Enter destination position (0 <= pos <= {self._length - 1}): ")
            try:
                dest_pos = int(dest)
                if not (0 <= dest_pos <= self._length - 1):
                    print("invalid move: destination out of range")
                    continue
            except ValueError:
                print("invalid move: not an integer")
                continue

            moving = self._sprites[sel_idx]
            src_pos = moving._position()

            # If moving to the same position (no-op), treat as no collision and continue
            if dest_pos == src_pos:
                print(f"No-op move: {moving.__class__.__name__} already at {dest_pos}")
                continue

            # 3. 判斷是否有碰撞
            target_sprite = self._find_sprite_at(dest_pos, exclude=moving)
            if target_sprite is None:
                # 4.1 無碰撞，直接移動並更新 coord
                print(f"Moving {moving.__class__.__name__} from {src_pos} to {dest_pos}")
                moving._move_to(dest_pos)
                continue

            # 4.2 有碰撞 -> delegate handling to sprites
            s1 = moving
            s2 = target_sprite
            print(f"Collision: {s1.__class__.__name__} ({src_pos} -> {dest_pos}) with {s2.__class__.__name__} at {dest_pos}")

            # ask both sprites what actions they want the world to perform
            actions1 = []
            actions2 = []
            if hasattr(s1, "_on_collision"):
                actions1 = s1._on_collision(s2) or []
            if hasattr(s2, "_on_collision"):
                actions2 = s2._on_collision(s1) or []

            # merge actions while preserving order and uniqueness
            actions = []
            for a in actions1 + actions2:
                if a not in actions:
                    actions.append(a)

            # If no handler produced any actions, treat the collision as blocking
            # and do not move the mover into the occupied position.
            if not actions:
                print("Move blocked: collision unresolved, movement cancelled")
                continue

            # apply actions
            removed = []
            for act in actions:
                if act[0] == "remove":
                    _, sprite_to_remove = act
                    if any(s is sprite_to_remove for s in self._sprites) and not any(r is sprite_to_remove for r in removed):
                        print(f"Removing {sprite_to_remove.__class__.__name__}")
                        self._sprites = [s for s in self._sprites if s is not sprite_to_remove]
                        removed.append(sprite_to_remove)
                elif act[0] == "move":
                    _, sprite_to_move, pos = act
                    if any(s is sprite_to_move for s in self._sprites) and not any(r is sprite_to_move for r in removed):
                        sprite_to_move._move_to(pos)

            # if no action prevented movement and the moving sprite still exists, move it
            if moving in self._sprites and moving not in removed:
                # if there was no explicit removal of moving or movement prohibition, move the mover
                moving._move_to(dest_pos)
            continue

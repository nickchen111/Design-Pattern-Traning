from .sprite import Sprite
from .collision_handler import  get_chain_for_class


class Water(Sprite):
    def _get_chain(self):
        return get_chain_for_class(type(self))

    def _on_collision(self, other: "Sprite") -> list:
        chain = self._get_chain()
        if chain is None:
            return []
        return chain._handle(self, other)


# Register handlers for Water at import time
# Registration is handled lazily by collision_handler._ensure_default_registrations

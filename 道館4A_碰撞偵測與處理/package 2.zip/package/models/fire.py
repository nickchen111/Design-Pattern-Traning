from .sprite import Sprite


class Fire(Sprite):
    pass


from .sprite import Sprite


class Water(Sprite):
    pass